package com.klef.jfsd.springboot.service;

public class TeacherServiceImpl implements TeacherService{

}
